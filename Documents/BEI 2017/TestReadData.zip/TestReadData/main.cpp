#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "saveData.h"
#include "readData.h"

using namespace std;

int main()
{
    int taille = 20001;
    long double test_tab[TAILLEMAX];

    readData(test_tab, "testprojet.txt");
    saveData(taille ,test_tab,"sauvegardetestprojet.txt");
    cout << "Hello World";
return 0;
}
